<div class="tfb-upgrade">
        <div class="tfb-upgrade-top"><img src="<?php echo TFB_IMG_DIR.'/upgrade/upgrade-top.png'?>"/></div>
        <div class="tfb-upgrade-action-wrap">
          <a href="http://demo.accesspressthemes.com/wordpress-plugins/ultimate-form-builder/" target="_blank" title="Demo"><img src="<?php echo TFB_IMG_DIR.'/upgrade/demo-btn.png'?>"/></a>
          <a href="http://codecanyon.net/item/ultimate-form-builder/14644208?ref=AccessKeys" target="_blank" title="Upgrade"><img src="<?php echo TFB_IMG_DIR.'/upgrade/upgrade-btn.png'?>"/></a>
        </div>
        <div class="tfb-upgrade-bottom"><img src="<?php echo TFB_IMG_DIR.'/upgrade/upgrade-bottom.png'?>"/></div>
        <div class="tfb-upgrade-action-wrap">
          <a href="http://demo.accesspressthemes.com/wordpress-plugins/ultimate-form-builder/" target="_blank" title="Demo"><img src="<?php echo TFB_IMG_DIR.'/upgrade/demo-btn.png'?>"/></a>
          <a href="http://codecanyon.net/item/ultimate-form-builder/14644208?ref=AccessKeys" target="_blank" title="Upgrade"><img src="<?php echo TFB_IMG_DIR.'/upgrade/upgrade-btn.png'?>"/></a>
        </div>
    </div>
    <div class="tfb-clear"></div>